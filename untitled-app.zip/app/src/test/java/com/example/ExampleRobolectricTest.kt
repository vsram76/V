package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.viewmodel.SystemCompanionViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Android 16 Support Hub", appName)
  }

  @Test
  fun `verify siri state defaults`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = SystemCompanionViewModel(app)
    val state = viewModel.uiState.value.siriState
    
    assertFalse(state.isListening)
    assertFalse(state.isServerRunning)
    assertEquals("", state.serverUrl)
  }

  @Test
  fun `verify siri server toggle workflow`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = SystemCompanionViewModel(app)
    
    // Toggle server ON
    viewModel.toggleSiriServer()
    var state = viewModel.uiState.value.siriState
    assertTrue(state.isServerRunning)
    assertTrue(state.serverUrl.startsWith("http://"))
    assertTrue(state.serverLogs.isNotEmpty())

    // Toggle server OFF
    viewModel.toggleSiriServer()
    state = viewModel.uiState.value.siriState
    assertFalse(state.isServerRunning)
    assertEquals("", state.serverUrl)
  }

  @Test
  fun `verify siri server command handler execution`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = SystemCompanionViewModel(app)
    
    // Trigger diagnostics command mock and check response string
    val diagResponse = viewModel.handleSiriServerCommand("diagnostics")
    assertTrue(diagResponse.contains("Android 16 diagnostics check complete"))
    assertTrue(diagResponse.contains("RAM utilization"))

    // Trigger app inspection list command mock and check response string
    val appsResponse = viewModel.handleSiriServerCommand("apps list")
    assertTrue(appsResponse.contains("You have"))
    assertTrue(appsResponse.contains("apps installed"))

    // Trigger notification cooldown reset command mock
    val resetResponse = viewModel.handleSiriServerCommand("reset cooldown")
    assertEquals("Notification cooldown timer reset successfully.", resetResponse)
  }
}
