package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AppInfo
import com.example.viewmodel.ChatMessage
import com.example.viewmodel.SenderType
import com.example.viewmodel.SystemCompanionViewModel
import com.example.viewmodel.DiagnosticLog
import com.example.viewmodel.DiagnosticsState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Enable edge-to-edge full-bleed drawing
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding(),
                    containerColor = MaterialTheme.colorScheme.background
                ) { innerPadding ->
                    SystemCompanionDashboard(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun SystemCompanionDashboard(
    modifier: Modifier = Modifier,
    viewModel: SystemCompanionViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("EduConnect", "Siri Voice", "AI Support", "Apps (" + uiState.installedApps.size + ")", "Android 16 Lab", "Diagnostics")

    Column(modifier = modifier) {
        // 1. Android 16 Simulated Interactive Status Bar Capsule
        Android16StatusBarCapsule(
            activeChip = uiState.featureLab.activeStatusChip,
            onDismissChip = { viewModel.triggerStatusChip(null) }
        )

        // 2. High-Tech Gradient Header Panel
        HeaderPanel()

        // 3. Tab Bar Navigation
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            contentColor = MaterialTheme.colorScheme.primary,
            edgePadding = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("tab_$index"),
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                )
            }
        }

        // 4. Content Screen Panels
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (selectedTab) {
                0 -> EduConnectScreen(
                    state = uiState.eduConnect,
                    onSearchQueryChange = { viewModel.updateEduSearchQuery(it) },
                    onCategoryFilterChange = { viewModel.updateEduCategoryFilter(it) },
                    onCreatePost = { title, cat, content -> viewModel.createEduPost(title, cat, content) },
                    onToggleLike = { viewModel.toggleEduPostLike(it) },
                    onDeletePost = { viewModel.deleteEduPost(it) }
                )
                1 -> SiriVoiceScreen(
                    state = uiState.siriState,
                    onToggleListening = { viewModel.toggleSiriListening() },
                    onSendSpeech = { viewModel.triggerSiriSpeech(it) },
                    onClearHistory = { viewModel.clearSiriHistory() },
                    onToggleServer = { viewModel.toggleSiriServer() }
                )
                2 -> GoogleSupportChatScreen(
                    chatHistory = uiState.chatHistory,
                    isChatLoading = uiState.isChatLoading,
                    chatError = uiState.chatError,
                    onSendMessage = { viewModel.sendMessage(it) }
                )
                3 -> AppInspectorScreen(
                    installedApps = uiState.installedApps,
                    searchQuery = uiState.searchQuery,
                    isLoadingApps = uiState.isLoadingApps,
                    onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                    onAskSupport = { viewModel.askSupportAboutApp(it) },
                    onRefresh = { viewModel.loadInstalledApps() }
                )
                4 -> Android16LabScreen(
                    state = uiState.featureLab,
                    onTogglePrivateSpace = { viewModel.togglePrivateSpaceLock(it) },
                    onTriggerStatusChip = { viewModel.triggerStatusChip(it) },
                    onToggleArchive = { viewModel.toggleAppArchive(it) },
                    onTriggerNotificationSpam = { viewModel.triggerNotificationSpam() },
                    onResetNotificationCooldown = { viewModel.resetNotificationCooldown() }
                )
                5 -> DiagnosticsScreen(
                    state = uiState.diagnostics,
                    onSearchQueryChange = { viewModel.updateLogsSearchQuery(it) },
                    onSelectedFilterChange = { viewModel.updateLogLevelFilter(it) },
                    onRefreshLogs = { viewModel.refreshDiagnosticLogs() }
                )
            }
        }
    }
}

// ==========================================
// COMPONENT: Simulated Android 16 Status Bar
// ==========================================
@Composable
fun Android16StatusBarCapsule(
    activeChip: String?,
    onDismissChip: () -> Unit
) {
    AnimatedVisibility(visible = activeChip != null) {
        if (activeChip != null) {
            val (bgColor, icon, label) = when (activeChip) {
                "mic" -> Triple(Color(0xFF2E7D32), Icons.Default.Mic, "Microphone: Live Google Asst")
                "screen" -> Triple(Color(0xFFC62828), Icons.Default.Videocam, "Screen Recording")
                "location" -> Triple(Color(0xFF1565C0), Icons.Default.MyLocation, "Google Maps GPS Connected")
                else -> Triple(Color.DarkGray, Icons.Default.Android, "Active Session")
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(vertical = 4.dp, horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(24.dp))
                        .background(bgColor)
                        .clickable { onDismissChip() }
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("status_bar_chip"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = "System status icon",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = label,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss",
                        tint = Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

// ==========================================
// COMPONENT: App Header
// ==========================================
@Composable
fun HeaderPanel() {
    val gradient = Brush.horizontalGradient(
        colors = listOf(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.secondary,
            MaterialTheme.colorScheme.tertiary
        )
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .background(gradient, alpha = 0.08f)
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Android,
                        contentDescription = "Android 16 Logo",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Android 16 Support Hub",
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Google System Support & App Integrity Portal",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Baklava API 36",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

// ==========================================
// TAB 1: Google AI Support Chat Screen
// ==========================================
@Composable
fun GoogleSupportChatScreen(
    chatHistory: List<ChatMessage>,
    isChatLoading: Boolean,
    chatError: String?,
    onSendMessage: (String) -> Unit
) {
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    var inputFieldValue by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    val quickQuestions = listOf(
        "What's new in Android 16 Baklava?",
        "How does App Archiving work?",
        "Explain Private Space Partitioning",
        "Diagnose background battery drain"
    )

    // Automatically scroll to the end on new messages
    LaunchedEffect(chatHistory.size) {
        if (chatHistory.isNotEmpty()) {
            listState.animateScrollToItem(chatHistory.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Chat list area
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(chatHistory, key = { it.id }) { message ->
                ChatBubble(message)
            }

            if (isChatLoading) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Google Support is writing...",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (chatError != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = "Error",
                                tint = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = chatError,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Suggestion Chips
        Text(
            text = "Suggested Questions:",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // To keep layout fully structured in standard rows
                val row1 = quickQuestions.take(2)
                val row2 = quickQuestions.drop(2)
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row1.forEach { q ->
                            SuggestionChip(
                                onClick = { onSendMessage(q) },
                                label = { Text(q, fontSize = 11.sp) },
                                modifier = Modifier.testTag("suggest_chip_${q.hashCode()}")
                            )
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row2.forEach { q ->
                            SuggestionChip(
                                onClick = { onSendMessage(q) },
                                label = { Text(q, fontSize = 11.sp) },
                                modifier = Modifier.testTag("suggest_chip_${q.hashCode()}")
                            )
                        }
                    }
                }
            }
        }

        // Input field and button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputFieldValue,
                onValueChange = { inputFieldValue = it },
                placeholder = { Text("Ask Google Assistant...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input"),
                shape = RoundedCornerShape(24.dp),
                maxLines = 3,
                keyboardOptions = KeyboardOptions(
                    imeAction = ImeAction.Send
                ),
                keyboardActions = KeyboardActions(
                    onSend = {
                        if (inputFieldValue.isNotBlank()) {
                            onSendMessage(inputFieldValue)
                            inputFieldValue = ""
                            keyboardController?.hide()
                        }
                    }
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (inputFieldValue.isNotBlank()) {
                        onSendMessage(inputFieldValue)
                        inputFieldValue = ""
                        keyboardController?.hide()
                    }
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .size(48.dp)
                    .testTag("send_button"),
                colors = IconButtonDefaults.iconButtonColors(contentColor = MaterialTheme.colorScheme.onPrimary)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send Message",
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val isGoogle = message.sender == SenderType.GEMINI_SUPPORT
    val alignment = if (isGoogle) Alignment.Start else Alignment.End
    val bubbleColor = if (isGoogle) {
        MaterialTheme.colorScheme.surfaceVariant
    } else {
        MaterialTheme.colorScheme.primary
    }
    val textColor = if (isGoogle) {
        MaterialTheme.colorScheme.onSurfaceVariant
    } else {
        MaterialTheme.colorScheme.onPrimary
    }
    val shape = if (isGoogle) {
        RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp)
    } else {
        RoundedCornerShape(16.dp, 16.dp, 4.dp, 16.dp)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalAlignment = alignment
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 2.dp)
        ) {
            if (isGoogle) {
                Icon(
                    imageVector = Icons.Default.SupportAgent,
                    contentDescription = "Google Support Agent",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Google Support representative",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            } else {
                Text(
                    text = "You (System Admin)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }

        Box(
            modifier = Modifier
                .widthIn(max = 290.dp)
                .clip(shape)
                .background(bubbleColor)
                .padding(12.dp)
        ) {
            Text(
                text = message.text,
                fontSize = 14.sp,
                color = textColor,
                lineHeight = 20.sp
            )
        }
    }
}

// ==========================================
// TAB 2: App Inspector Screen (Installed apps)
// ==========================================
@Composable
fun AppInspectorScreen(
    installedApps: List<AppInfo>,
    searchQuery: String,
    isLoadingApps: Boolean,
    onSearchQueryChange: (String) -> Unit,
    onAskSupport: (AppInfo) -> Unit,
    onRefresh: () -> Unit
) {
    val filteredApps = remember(installedApps, searchQuery) {
        installedApps.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.packageName.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Search & Refresh Action Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Search installed packages...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("app_search_field"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = onRefresh,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .size(48.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh Apps")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Apps summary stats
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val totalCount = installedApps.size
            val systemCount = installedApps.count { it.isSystemApp }
            val userCount = totalCount - systemCount

            StatLabel("Total Apps: $totalCount")
            StatLabel("System: $systemCount")
            StatLabel("User: $userCount")
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (isLoadingApps) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Scanning system applications...", style = MaterialTheme.typography.labelMedium)
                }
            }
        } else if (filteredApps.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No applications match your search query.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredApps, key = { it.packageName }) { app ->
                    AppInspectorItemCard(app = app, onAskSupport = onAskSupport)
                }
            }
        }
    }
}

@Composable
fun StatLabel(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun AppInspectorItemCard(
    app: AppInfo,
    onAskSupport: (AppInfo) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clickable { expanded = !expanded }
            .testTag("app_card_${app.packageName}"),
        colors = CardDefaults.cardColors(
            containerColor = if (expanded) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (expanded) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
            } else {
                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
            }
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Dynamically fetched system package icons
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    AppIcon(packageName = app.packageName, modifier = Modifier.size(28.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = app.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = app.packageName,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (app.targetSdkVersion >= 36) {
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                }
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Target SDK: ${app.targetSdkVersion}",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (app.targetSdkVersion >= 36) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (app.isSystemApp) "System App" else "User App",
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
            }

            if (expanded) {
                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Version Code",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(text = app.versionName, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                    Column {
                        Text(
                            text = "Sandbox Compatibility",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = if (app.targetSdkVersion >= 36) "A16 Direct Sandbox" else "Backward Optimized",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { onAskSupport(app) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp)
                        .testTag("ask_support_app_${app.packageName}"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SupportAgent,
                        contentDescription = "Ask support icon",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Analyze & Debug App with Google Support AI", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun AppIcon(packageName: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val drawable = remember(packageName) {
        try {
            context.packageManager.getApplicationIcon(packageName)
        } catch (e: Exception) {
            context.packageManager.defaultActivityIcon
        }
    }

    AndroidView(
        factory = { ctx ->
            android.widget.ImageView(ctx).apply {
                setImageDrawable(drawable)
            }
        },
        modifier = modifier
    )
}

// ==========================================
// TAB 3: Android 16 (Baklava) Lab Screen
// ==========================================
@Composable
fun Android16LabScreen(
    state: FeatureLabState,
    onTogglePrivateSpace: (String) -> Unit,
    onTriggerStatusChip: (String?) -> Unit,
    onToggleArchive: (String) -> Unit,
    onTriggerNotificationSpam: () -> Unit,
    onResetNotificationCooldown: () -> Unit
) {
    var pinInputValue by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Lab Intro Text
        item {
            Text(
                text = "Android 16 (Baklava) Experimental Laboratory",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Simulate and preview brand-new core system features specified for Android 16 (API 36).",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Feature 1: App Archiving Simulator
        item {
            FeatureSimulatorCard(
                title = "1. Native App Archiving API",
                description = "Android 16 introduces system-level App Archiving. When space is low, apps are archived, keeping only document states (reduces footprint by 90%). Tap to immediately restore.",
                icon = Icons.Default.CloudDownload
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.archivedApps.forEach { (packageName, isArchived) ->
                        val simpleName = packageName.substringAfterLast(".")
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isArchived) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                            else MaterialTheme.colorScheme.secondary.copy(alpha = 0.1f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isArchived) Icons.Default.CloudDownload else Icons.Default.CheckCircle,
                                        contentDescription = "Status",
                                        tint = if (isArchived) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = simpleName.replaceFirstChar { it.uppercase() },
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        textDecoration = if (isArchived) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                                    )
                                    Text(
                                        text = if (isArchived) "Size: 1.2 MB (Archived)" else "Size: 124.0 MB (Full)",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Button(
                                onClick = { onToggleArchive(packageName) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isArchived) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier
                                    .height(28.dp)
                                    .testTag("archive_btn_$simpleName")
                            ) {
                                Text(
                                    text = if (isArchived) "Restore" else "Archive",
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Feature 2: Private Space Partitioning
        item {
            FeatureSimulatorCard(
                title = "2. Biometric Private Space API",
                description = "Android 16 integrates 'Private Space' - a cryptographically secure, isolated profile layout hidden from launcher lists until authenticated.",
                icon = Icons.Default.Lock
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (state.isPrivateSpaceUnlocked) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.LockOpen, contentDescription = "Unlocked", tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Private Space Unlocked", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Secure isolated items stored in Private Sandbox:", fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                SecureAppItem("Google Wallet (Private Key Storage)")
                                SecureAppItem("Play Integrity Sandbox Logs")
                                SecureAppItem("Encrypted Workspace Vault")

                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedButton(
                                    onClick = { onTogglePrivateSpace("") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(36.dp)
                                        .testTag("lock_private_space")
                                ) {
                                    Text("Re-Lock Private Space", fontSize = 11.sp)
                                }
                            }
                        }
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Locked Space",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Private Space is Locked",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "Enter simulated pin '1234' to authenticate:",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = pinInputValue,
                                    onValueChange = { pinInputValue = it },
                                    placeholder = { Text("Enter 4-Digit PIN") },
                                    visualTransformation = PasswordVisualTransformation(),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("private_pin_input"),
                                    singleLine = true,
                                    textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        onTogglePrivateSpace(pinInputValue)
                                        pinInputValue = ""
                                    },
                                    modifier = Modifier
                                        .height(48.dp)
                                        .testTag("unlock_private_space_btn"),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Unlock", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Feature 3: Notification Cool-down Simulation
        item {
            FeatureSimulatorCard(
                title = "3. Adaptive Notification Cool-down",
                description = "To prevent alert fatigue, Android 16 automatically detects if an app is sending rapid spam notifications. It smoothly lowers notification alert volume and groups notifications.",
                icon = Icons.Default.VolumeMute
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Alerts Triggered: ${state.notificationCooldownSpamCount}",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (state.isNotificationCooledDown) Color(0xFFE53935).copy(alpha = 0.15f)
                                    else Color(0xFF43A047).copy(alpha = 0.15f)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (state.isNotificationCooledDown) "COOL-DOWN ACTIVE: MUTED" else "STATUS: VOLUMES NORMAL",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (state.isNotificationCooledDown) Color(0xFFD32F2F) else Color(0xFF388E3C)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = (state.notificationCooldownSpamCount / 4f).coerceAtMost(1f),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = onTriggerNotificationSpam,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("spam_notif_btn"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Simulate Rapid Alert Spam", fontSize = 10.sp)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = onResetNotificationCooldown,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("reset_notif_btn"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Reset Cooldown", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // Feature 4: Rich Status Bar Simulation Trigger
        item {
            FeatureSimulatorCard(
                title = "4. Rich Status Bar Capsule API",
                description = "Android 16 allows background apps to request visual capsule chips directly in the system status bar, mimicking interactive islands. Tap below to simulate launching one:",
                icon = Icons.Default.DeveloperMode
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusChipTriggerBtn(
                        label = "Mic Active",
                        icon = Icons.Default.Mic,
                        color = Color(0xFF2E7D32),
                        onClick = { onTriggerStatusChip("mic") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("trigger_mic_chip")
                    )
                    StatusChipTriggerBtn(
                        label = "Rec Active",
                        icon = Icons.Default.Videocam,
                        color = Color(0xFFC62828),
                        onClick = { onTriggerStatusChip("screen") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("trigger_screen_chip")
                    )
                    StatusChipTriggerBtn(
                        label = "Maps Active",
                        icon = Icons.Default.MyLocation,
                        color = Color(0xFF1565C0),
                        onClick = { onTriggerStatusChip("location") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("trigger_location_chip")
                    )
                }
            }
        }
    }
}

@Composable
fun SecureAppItem(name: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Shield,
            contentDescription = "Shield",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = name, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun StatusChipTriggerBtn(
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.1f))
            .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun FeatureSimulatorCard(
    title: String,
    description: String,
    icon: ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = "Feature Icon",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = description,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

// ==========================================
// TAB 4: Device Diagnostics Screen
// ==========================================
@Composable
fun DiagnosticsScreen(
    state: DiagnosticsState,
    onSearchQueryChange: (String) -> Unit,
    onSelectedFilterChange: (String) -> Unit,
    onRefreshLogs: () -> Unit
) {
    val filteredLogs = remember(state.systemLogs, state.logsSearchQuery, state.selectedLogLevelFilter) {
        state.systemLogs.filter { log ->
            val matchesSearch = log.message.contains(state.logsSearchQuery, ignoreCase = true) ||
                    log.component.contains(state.logsSearchQuery, ignoreCase = true)
            val matchesFilter = state.selectedLogLevelFilter == "ALL" || log.level.equals(state.selectedLogLevelFilter, ignoreCase = true)
            matchesSearch && matchesFilter
        }
    }

    var showExportDialog by remember { mutableStateOf(false) }

    if (showExportDialog) {
        LogExportDialog(
            allLogs = state.systemLogs,
            filteredLogs = filteredLogs,
            onDismiss = { showExportDialog = false }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Google System Health Monitor",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Real-time query integrity diagnostics & virtual virtualization check.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Stats Matrix Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    DiagnosticsGridItem(
                        title = "OS Engine",
                        value = state.androidVersion,
                        icon = Icons.Default.Android,
                        modifier = Modifier.weight(1f)
                    )
                    DiagnosticsGridItem(
                        title = "API Level",
                        value = "Level ${state.sdkVersion}",
                        icon = Icons.Default.Code,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    DiagnosticsGridItem(
                        title = "Service Core",
                        value = state.googlePlayServicesStatus,
                        icon = Icons.Default.Dns,
                        modifier = Modifier.weight(1f)
                    )
                    DiagnosticsGridItem(
                        title = "Architecture",
                        value = state.cpuArchitecture,
                        icon = Icons.Default.Memory,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Memory Usage Meter
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Memory, contentDescription = "RAM", tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Virtual RAM Usage", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Text("${state.mockRamUsagePercent}% Active", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = state.mockRamUsagePercent / 100f,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Allocated RAM partition sandbox: 3.4 GB / 8.0 GB",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Storage Usage Meter
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Folder, contentDescription = "Storage", tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sandbox Storage Space", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Text("${state.mockTotalStorageGB - state.mockAvailableStorageGB} GB Used", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = (state.mockTotalStorageGB - state.mockAvailableStorageGB) / state.mockTotalStorageGB.toFloat(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "${state.mockAvailableStorageGB} GB available of ${state.mockTotalStorageGB} GB system storage",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Security / Integrity State
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.1f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Shield Guard",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Google Play Protect API active", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        Text(
                            "Safe sandbox encryption active. System is optimized for Android 16 deployment.",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Searchable Log Viewer Component Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .testTag("diagnostic_log_viewer_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ReceiptLong,
                                contentDescription = "Log Viewer",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("System Log Diagnostics", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Export Logs Button
                            IconButton(
                                onClick = { showExportDialog = true },
                                modifier = Modifier.size(32.dp).testTag("export_logs_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Export system logs",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Pull Fresh Logs Button
                            if (state.isRefreshingLogs) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            } else {
                                IconButton(
                                    onClick = onRefreshLogs,
                                    modifier = Modifier.size(32.dp).testTag("refresh_logs_btn")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Pull fresh logs",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Analyze inter-process system telemetry and event flags from virtual sandbox environments in real-time.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 16.sp
                    )
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    // Search bar
                    OutlinedTextField(
                        value = state.logsSearchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("Search logs by message or component...", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Logs", modifier = Modifier.size(16.dp)) },
                        trailingIcon = {
                            if (state.logsSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchQueryChange("") }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("logs_search_field"),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true,
                        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                    )
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    // Log Level filter chips
                    val levels = listOf("ALL", "INFO", "WARN", "ERROR", "DEBUG")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        levels.forEach { level ->
                            val isSelected = state.selectedLogLevelFilter == level
                            val chipColor = when (level) {
                                "INFO" -> Color(0xFF2E7D32)
                                "WARN" -> Color(0xFFEF6C00)
                                "ERROR" -> Color(0xFFC62828)
                                "DEBUG" -> Color(0xFF6A1B9A)
                                else -> MaterialTheme.colorScheme.primary
                            }
                            
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        if (isSelected) chipColor.copy(alpha = 0.15f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) chipColor else Color.Transparent,
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .clickable { onSelectedFilterChange(level) }
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                                    .testTag("log_filter_chip_$level")
                            ) {
                                Text(
                                    text = level,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) chipColor else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(14.dp))
                    
                    // Table Header Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(vertical = 8.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Time",
                            modifier = Modifier.weight(0.18f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "Component",
                            modifier = Modifier.weight(0.32f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "Level",
                            modifier = Modifier.weight(0.18f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "Message",
                            modifier = Modifier.weight(0.32f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    
                    // Table Content rows
                    if (filteredLogs.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "No system logs found matching filters.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        // Display log list
                        var selectedLogForDetail by remember { mutableStateOf<DiagnosticLog?>(null) }
                        val context = LocalContext.current
                        
                        Column(modifier = Modifier.fillMaxWidth()) {
                            filteredLogs.forEachIndexed { idx, log ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedLogForDetail = log }
                                        .background(
                                            if (idx % 2 == 1) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)
                                            else Color.Transparent
                                        )
                                        .padding(vertical = 10.dp, horizontal = 6.dp)
                                        .testTag("log_row_${log.id}"),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Time
                                    Text(
                                        text = log.timestamp,
                                        modifier = Modifier.weight(0.18f),
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    // Component
                                    Text(
                                        text = log.component,
                                        modifier = Modifier.weight(0.32f),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    // Level Pill
                                    val (levelBg, levelText) = when (log.level) {
                                        "INFO" -> Pair(Color(0xFFE8F5E9), Color(0xFF2E7D32))
                                        "WARN" -> Pair(Color(0xFFFFF3E0), Color(0xFFEF6C00))
                                        "ERROR" -> Pair(Color(0xFFFFEBEE), Color(0xFFC62828))
                                        "DEBUG" -> Pair(Color(0xFFF3E5F5), Color(0xFF6A1B9A))
                                        else -> Pair(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    
                                    Box(
                                        modifier = Modifier
                                            .weight(0.18f)
                                            .padding(end = 4.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(levelBg)
                                            .padding(horizontal = 4.dp, vertical = 2.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = log.level,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = levelText
                                        )
                                    }
                                    // Message
                                    Text(
                                        text = log.message,
                                        modifier = Modifier.weight(0.32f),
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.04f))
                            }
                            
                            // Dialogue popup for full log detail
                            selectedLogForDetail?.let { log ->
                                AlertDialog(
                                    onDismissRequest = { selectedLogForDetail = null },
                                    icon = {
                                        Icon(
                                            imageVector = when (log.level) {
                                                "WARN" -> Icons.Default.Warning
                                                "ERROR" -> Icons.Default.Error
                                                "DEBUG" -> Icons.Default.BugReport
                                                else -> Icons.Default.Info
                                            },
                                            contentDescription = log.level,
                                            tint = when (log.level) {
                                                "INFO" -> Color(0xFF2E7D32)
                                                "WARN" -> Color(0xFFEF6C00)
                                                "ERROR" -> Color(0xFFC62828)
                                                "DEBUG" -> Color(0xFF6A1B9A)
                                                else -> MaterialTheme.colorScheme.primary
                                            }
                                        )
                                    },
                                    title = {
                                        Text(
                                            text = "Diagnostic Log Event",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp
                                        )
                                    },
                                    text = {
                                        Column(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            LogDetailRow("Log ID", log.id)
                                            LogDetailRow("Timestamp", log.timestamp)
                                            LogDetailRow("Component", log.component)
                                            LogDetailRow("Level", log.level)
                                            
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                "Complete Payload Message:",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                                    .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), RoundedCornerShape(4.dp))
                                                    .padding(10.dp)
                                            ) {
                                                Text(
                                                    text = log.message,
                                                    fontSize = 12.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    },
                                    confirmButton = {
                                        TextButton(
                                            onClick = {
                                                val clipboardManager = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                val clip = android.content.ClipData.newPlainText("Diagnostic Log", "[${log.timestamp}] [${log.component}] [${log.level}] ${log.message}")
                                                clipboardManager.setPrimaryClip(clip)
                                                android.widget.Toast.makeText(context, "Copied log payload to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Copy Log")
                                            }
                                        }
                                    },
                                    dismissButton = {
                                        TextButton(onClick = { selectedLogForDetail = null }) {
                                            Text("Close")
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LogExportDialog(
    allLogs: List<DiagnosticLog>,
    filteredLogs: List<DiagnosticLog>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedFormat by remember { mutableStateOf("JSON") } // "JSON" or "CSV"
    var selectedScope by remember { mutableStateOf("FILTERED") } // "FILTERED" or "ALL"
    
    val logsToExport = remember(selectedScope, allLogs, filteredLogs) {
        if (selectedScope == "ALL") allLogs else filteredLogs
    }
    
    val exportedText = remember(selectedFormat, logsToExport) {
        if (selectedFormat == "JSON") {
            buildString {
                append("[\n")
                logsToExport.forEachIndexed { index, log ->
                    append("  {\n")
                    append("    \"id\": \"${log.id.replace("\"", "\\\"")}\",\n")
                    append("    \"timestamp\": \"${log.timestamp.replace("\"", "\\\"")}\",\n")
                    append("    \"component\": \"${log.component.replace("\"", "\\\"")}\",\n")
                    append("    \"level\": \"${log.level.replace("\"", "\\\"")}\",\n")
                    append("    \"message\": \"${log.message.replace("\"", "\\\"")}\"\n")
                    append("  }")
                    if (index < logsToExport.lastIndex) {
                        append(",")
                    }
                    append("\n")
                }
                append("]")
            }
        } else {
            buildString {
                append("id,timestamp,component,level,message\n")
                logsToExport.forEach { log ->
                    val safeId = log.id.replace("\"", "\"\"").let { if (it.contains(",") || it.contains("\n") || it.contains("\"")) "\"$it\"" else it }
                    val safeTime = log.timestamp.replace("\"", "\"\"").let { if (it.contains(",") || it.contains("\n") || it.contains("\"")) "\"$it\"" else it }
                    val safeComp = log.component.replace("\"", "\"\"").let { if (it.contains(",") || it.contains("\n") || it.contains("\"")) "\"$it\"" else it }
                    val safeLevel = log.level.replace("\"", "\"\"").let { if (it.contains(",") || it.contains("\n") || it.contains("\"")) "\"$it\"" else it }
                    val safeMsg = log.message.replace("\"", "\"\"").let { if (it.contains(",") || it.contains("\n") || it.contains("\"")) "\"$it\"" else it }
                    append("$safeId,$safeTime,$safeComp,$safeLevel,$safeMsg\n")
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.Share,
                contentDescription = "Export Diagnostics Icon",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
        },
        title = {
            Text(
                text = "Export System Logs",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Export and save diagnostic system health reports to JSON or CSV formats.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                // Format Selector (JSON vs CSV)
                Text(
                    text = "1. SELECT FORMAT",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("JSON", "CSV").forEach { format ->
                        val isSelected = selectedFormat == format
                        Button(
                            onClick = { selectedFormat = format },
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("export_format_$format"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(format, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                
                // Scope Selector (Filtered vs All)
                Text(
                    text = "2. SELECT SCOPE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val scopeOptions = listOf(
                        "FILTERED" to "Filtered (${filteredLogs.size})",
                        "ALL" to "All Logs (${allLogs.size})"
                    )
                    scopeOptions.forEach { (scopeKey, scopeLabel) ->
                        val isSelected = selectedScope == scopeKey
                        Button(
                            onClick = { selectedScope = scopeKey },
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("export_scope_$scopeKey"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(scopeLabel, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                
                // Preview Section
                Text(
                    text = "3. DATA PREVIEW",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .border(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    val previewLines = remember(exportedText) {
                        exportedText.lines().take(15).joinToString("\n") + if (exportedText.lines().size > 15) "\n... [truncated preview]" else ""
                    }
                    Box(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        Text(
                            text = previewLines,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            lineHeight = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Copy to Clipboard
                TextButton(
                    onClick = {
                        val clipboardManager = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        val clip = android.content.ClipData.newPlainText("Diagnostic Logs", exportedText)
                        clipboardManager.setPrimaryClip(clip)
                        android.widget.Toast.makeText(context, "Copied log report to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("export_copy_btn")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Copy", fontSize = 12.sp)
                    }
                }
                
                // Share File (Intents)
                Button(
                    onClick = {
                        val fileExt = if (selectedFormat == "JSON") "json" else "csv"
                        val filename = "system_diagnostics_report_${System.currentTimeMillis()}.$fileExt"
                        
                        try {
                            val file = java.io.File(context.getExternalFilesDir(null), filename)
                            file.writeText(exportedText)
                            
                            val sendIntent = android.content.Intent().apply {
                                action = android.content.Intent.ACTION_SEND
                                putExtra(android.content.Intent.EXTRA_TEXT, exportedText)
                                putExtra(android.content.Intent.EXTRA_SUBJECT, "System Health Logs - $fileExt")
                                type = "text/plain"
                            }
                            val shareIntent = android.content.Intent.createChooser(sendIntent, "Share Diagnostics Logs")
                            context.startActivity(shareIntent)
                            
                            android.widget.Toast.makeText(
                                context,
                                "File exported & saved locally to Android Sandbox files: $filename",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Failed to write file: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.testTag("export_share_btn"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Share & Save", fontSize = 12.sp)
                    }
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("export_cancel_btn")
            ) {
                Text("Cancel", fontSize = 12.sp)
            }
        },
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
fun LogDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
fun DiagnosticsGridItem(
    title: String,
    value: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = title, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
            Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ==========================================
// TAB 0: Siri Voice Assistant Screen
// ==========================================
@Composable
fun SiriVoiceScreen(
    state: com.example.viewmodel.SiriState,
    onToggleListening: () -> Unit,
    onSendSpeech: (String) -> Unit,
    onClearHistory: () -> Unit,
    onToggleServer: () -> Unit
) {
    var textInput by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    val presetQueries = listOf(
        "Android 16 features",
        "Explain App Archiving",
        "Check system diagnostics",
        "Why 'Baklava' dessert?"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Intro & Header Title
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Siri Voice Assistant",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFF355DA) // Distinct Siri magenta accent color
                    )
                    Text(
                        text = "Virtual Voice Assistant Companion adapted for Android 16",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = onClearHistory,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear History",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // 1. High-Fidelity Siri Waveform Visualizer
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SiriVoiceWaveform(
                    isListening = state.isListening,
                    isGenerating = state.isGenerating,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Status Text
                Text(
                    text = when {
                        state.isListening -> "Siri is listening... Say something or tap a preset below"
                        state.isGenerating -> "Siri is thinking..."
                        else -> "Waveform Idle. Tap the mic to speak."
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = if (state.isListening) Color(0xFF00F2FE) else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // 2. Interactive Voice Activation Button (Mic)
        item {
            val buttonGlowColor by animateColorAsState(
                targetValue = if (state.isListening) Color(0xFF00F2FE) else MaterialTheme.colorScheme.primary,
                label = "buttonGlow"
            )

            val buttonScale by animateFloatAsState(
                targetValue = if (state.isListening) 1.15f else 1.0f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioHighBouncy, stiffness = Spring.StiffnessMedium),
                label = "buttonScale"
            )

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .clickable { onToggleListening() }
                    .testTag("siri_mic_button")
            ) {
                // Outer pulsing rings when listening
                if (state.isListening) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .border(2.dp, buttonGlowColor.copy(alpha = 0.4f), CircleShape)
                    )
                }
                
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    buttonGlowColor,
                                    buttonGlowColor.copy(alpha = 0.7f)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (state.isListening) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Siri Mic Toggle",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        // 3. Current Voice Transcript Bubble
        if (state.voiceTranscript.isNotEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = "Voice Input",
                            tint = Color(0xFF00F2FE),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = state.voiceTranscript,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 4. Siri Intelligent Response Panel
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF131325) // Siri Deep Space Purple Container
                ),
                border = BorderStroke(1.dp, Color(0xFF2E224A)),
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF355DA).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Assistant,
                                contentDescription = "Siri Assistant",
                                tint = Color(0xFFF355DA),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SIRI RESPONSE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF355DA)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (state.isGenerating) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            LinearProgressIndicator(
                                modifier = Modifier.fillMaxWidth(),
                                color = Color(0xFF00F2FE),
                                trackColor = Color(0xFF131325)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Siri is synthesizing answer...",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Text(
                            text = state.siriResponse,
                            fontSize = 13.sp,
                            color = Color.White,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }

        // 5. Preset Voice Quick Actions Grid
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Quick Siri Voice Commands",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Layout preset actions in a 2x2 grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SiriPresetActionBtn(
                        label = presetQueries[0],
                        onClick = { onSendSpeech("Hey Siri, " + presetQueries[0]) },
                        modifier = Modifier.weight(1f).testTag("preset_siri_0")
                    )
                    SiriPresetActionBtn(
                        label = presetQueries[1],
                        onClick = { onSendSpeech("Hey Siri, " + presetQueries[1]) },
                        modifier = Modifier.weight(1f).testTag("preset_siri_1")
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SiriPresetActionBtn(
                        label = presetQueries[2],
                        onClick = { onSendSpeech("Hey Siri, " + presetQueries[2]) },
                        modifier = Modifier.weight(1f).testTag("preset_siri_2")
                    )
                    SiriPresetActionBtn(
                        label = presetQueries[3],
                        onClick = { onSendSpeech("Hey Siri, " + presetQueries[3]) },
                        modifier = Modifier.weight(1f).testTag("preset_siri_3")
                    )
                }
            }
        }

        // 6. Manual Speech Text Input Bar
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text("Or type question for Siri...", fontSize = 12.sp) },
                    singleLine = true,
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFF355DA),
                        unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("siri_text_input"),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (textInput.isNotBlank()) {
                                onSendSpeech(textInput)
                                textInput = ""
                                keyboardController?.hide()
                            }
                        }
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            onSendSpeech(textInput)
                            textInput = ""
                            keyboardController?.hide()
                        }
                    },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFFF355DA))
                        .size(48.dp)
                        .testTag("siri_send_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send text speech",
                        tint = Color.White
                    )
                }
            }
        }

        // 7. Apple Siri Shortcuts Integration Module
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Title with Apple icon-like circle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFF355DA)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SettingsInputComponent,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Siri Shortcuts API Server",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "Interface with Apple Shortcuts App via Webhook",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Server Toggle Button
                        Switch(
                            checked = state.isServerRunning,
                            onCheckedChange = { onToggleServer() },
                            modifier = Modifier.testTag("siri_server_toggle"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF00F2FE),
                                checkedTrackColor = Color(0xFF00F2FE).copy(alpha = 0.4f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Live Webhook URI Display
                    if (state.isServerRunning) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0F0F1A))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "🟢 Server Listening on Wi-Fi Network",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00FF87)
                                )
                                Divider(color = Color(0xFF22223B), modifier = Modifier.padding(vertical = 4.dp))
                                
                                Text(
                                    text = "Diagnostics Endpoint (JSON):",
                                    fontSize = 10.sp,
                                    color = Color(0xFFF355DA),
                                    fontWeight = FontWeight.Bold
                                )
                                SelectionContainer {
                                    Text(
                                        text = "${state.serverUrl}/siri/diagnostics",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        color = Color.White
                                    )
                                }

                                Text(
                                    text = "App Inspector Endpoint:",
                                    fontSize = 10.sp,
                                    color = Color(0xFFF355DA),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                                SelectionContainer {
                                    Text(
                                        text = "${state.serverUrl}/siri/apps",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        color = Color.White
                                    )
                                }

                                Text(
                                    text = "Voice Command Webhook (Run Actions):",
                                    fontSize = 10.sp,
                                    color = Color(0xFFF355DA),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                                SelectionContainer {
                                    Text(
                                        text = "${state.serverUrl}/siri/command?cmd=spam",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E1E1E))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🔴 Server is Offline. Enable the toggle above to interface with Apple Siri.",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // iOS Siri Shortcut Configurator Tutorial Checklist
                    Text(
                        text = "How to configure Siri Shortcuts on iOS:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SiriStepRow(
                            stepNumber = "1",
                            instruction = "Open the official 'Shortcuts' app on your Apple device."
                        )
                        SiriStepRow(
                            stepNumber = "2",
                            instruction = "Tap '+' to create a new shortcut, and name it: 'Check Android status'."
                        )
                        SiriStepRow(
                            stepNumber = "3",
                            instruction = "Add action 'Get Contents of URL'. Paste the Diagnostics Endpoint above."
                        )
                        SiriStepRow(
                            stepNumber = "4",
                            instruction = "Add a 'Show Result' action. Now, activate Siri on iOS and say: 'Hey Siri, Check Android status'!"
                        )
                    }

                    // Log Terminal output
                    if (state.isServerRunning && state.serverLogs.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(18.dp))
                        Text(
                            text = "Live Siri Server Access Logs:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color(0xFF00F2FE)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF050510))
                                .border(1.dp, Color(0xFF1A1A3A))
                                .padding(8.dp)
                        ) {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(state.serverLogs.reversed()) { logLine ->
                                    Text(
                                        text = logLine,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        color = Color(0xFF33FF33)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SiriStepRow(stepNumber: String, instruction: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(Color(0xFFF355DA).copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stepNumber,
                color = Color(0xFFF355DA),
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = instruction,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            lineHeight = 15.sp
        )
    }
}

@Composable
fun SiriPresetActionBtn(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)),
        modifier = modifier
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.KeyboardArrowRight,
                contentDescription = null,
                tint = Color(0xFFF355DA),
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SiriVoiceWaveform(
    isListening: Boolean,
    isGenerating: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "siri_wave")
    
    // Wave animation phase shift
    val phaseShift by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(if (isGenerating) 1000 else if (isListening) 1400 else 3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    // Base scale of waves based on state
    val waveScale by animateFloatAsState(
        targetValue = if (isGenerating) 1.2f else if (isListening) 2.2f else 0.3f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "scale"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0F0F1A)) // Cosmic midnight dark card background
            .border(1.dp, Color(0xFF22223B), RoundedCornerShape(16.dp))
    ) {
        val width = size.width
        val height = size.height
        val centerY = height / 2f
        
        // Define beautiful Siri Apple-style neon colors
        val colors = listOf(
            Color(0xFF00F2FE), // Bright Cyan
            Color(0xFF4FACFE), // Electric Blue
            Color(0xFFF355DA), // Hot Pink/Magenta
            Color(0xFF9B51E0)  // Cosmic Violet
        )

        // Draw multiple overlapping waves with pinched envelope
        for (i in 0 until 4) {
            val color = colors[i]
            val path = Path()
            path.moveTo(0f, centerY)

            val frequency = (i + 1) * 0.012f + 0.005f
            val amplitude = (35f - (i * 6f)) * waveScale
            val phaseOffset = i * (Math.PI / 3).toFloat()

            for (x in 0..width.toInt() step 5) {
                // Modulate amplitude with a Gaussian-like bell curve so the wave is pinched at both ends
                val normalizedX = x / width
                val envelope = Math.sin(normalizedX * Math.PI).toFloat() // 0 at ends, 1 in middle
                
                val y = centerY + (amplitude * envelope * Math.sin(x * frequency + phaseShift + phaseOffset).toFloat())
                path.lineTo(x.toFloat(), y)
            }
            
            drawPath(
                path = path,
                color = color.copy(alpha = if (isListening) 0.7f else if (isGenerating) 0.5f else 0.2f),
                style = Stroke(width = (4f - (i * 0.6f)).coerceAtLeast(1.5f))
            )
        }
    }
}

// ==========================================
// COMPONENT: EduConnect (Mini-Social & Search Portal)
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EduConnectScreen(
    state: com.example.viewmodel.EduConnectState,
    onSearchQueryChange: (String) -> Unit,
    onCategoryFilterChange: (String) -> Unit,
    onCreatePost: (title: String, category: String, content: String) -> Unit,
    onToggleLike: (postId: String) -> Unit,
    onDeletePost: (postId: String) -> Unit
) {
    val context = LocalContext.current
    var showCreateForm by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("") }
    var newContent by remember { mutableStateOf("") }

    val filteredPosts = remember(state.posts, state.searchQuery, state.selectedCategoryFilter) {
        state.posts.filter { post ->
            val matchesQuery = state.searchQuery.isBlank() ||
                    post.title.contains(state.searchQuery, ignoreCase = true) ||
                    post.category.contains(state.searchQuery, ignoreCase = true) ||
                    post.content.contains(state.searchQuery, ignoreCase = true)

            val matchesCategory = state.selectedCategoryFilter == "ALL" ||
                    post.category.equals(state.selectedCategoryFilter, ignoreCase = true)

            matchesQuery && matchesCategory
        }
    }

    val categories = remember(state.posts) {
        val extracted = state.posts.map { it.category }.distinct()
        listOf("ALL") + (extracted + listOf("Programming", "Web Development", "Database", "Digital Electronics", "Maths")).distinct().filterNot { it == "ALL" }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("edu_connect_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Banner Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("edu_banner_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.School,
                                    contentDescription = "EduConnect Icon",
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "EduConnect",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Mini-Social Feed & Search Engine",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        IconButton(
                            onClick = { showCreateForm = !showCreateForm },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                                .size(36.dp)
                                .testTag("toggle_create_post_btn")
                        ) {
                            Icon(
                                imageVector = if (showCreateForm) Icons.Default.Close else Icons.Default.Add,
                                contentDescription = "Create Post",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        // Google-like Realtime Search Bar Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("edu_search_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Search Educational Feed",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = state.searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("Type to search by title, category, or content...", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        trailingIcon = {
                            if (state.searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchQueryChange("") }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("edu_search_input"),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true,
                        textStyle = LocalTextStyle.current.copy(fontSize = 12.sp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Category Filter Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        categories.forEach { category ->
                            val isSelected = state.selectedCategoryFilter.equals(category, ignoreCase = true)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .clickable { onCategoryFilterChange(category) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                                    .testTag("edu_category_chip_$category")
                            ) {
                                Text(
                                    text = category,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Instagram-like Share / Create Post Card
        if (showCreateForm) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edu_create_post_card"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .animateContentSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Create,
                                contentDescription = "Create",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Create a New Post to Feed",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        OutlinedTextField(
                            value = newTitle,
                            onValueChange = { newTitle = it },
                            label = { Text("Post Title", fontSize = 12.sp) },
                            placeholder = { Text("e.g. Intro to Python / SQL Normalization", fontSize = 12.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edu_post_title_input"),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                        )

                        OutlinedTextField(
                            value = newCategory,
                            onValueChange = { newCategory = it },
                            label = { Text("Category", fontSize = 12.sp) },
                            placeholder = { Text("e.g. Programming, Database, Maths", fontSize = 12.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("edu_post_category_input"),
                            shape = RoundedCornerShape(8.dp),
                            singleLine = true,
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                        )

                        // Quick category chips
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("Programming", "Web Development", "Database", "Digital Electronics", "Maths").forEach { tag ->
                                AssistChip(
                                    onClick = { newCategory = tag },
                                    label = { Text(tag, fontSize = 10.sp) },
                                    modifier = Modifier.height(28.dp)
                                )
                            }
                        }

                        OutlinedTextField(
                            value = newContent,
                            onValueChange = { newContent = it },
                            label = { Text("Content / Educational Note", fontSize = 12.sp) },
                            placeholder = { Text("Write your educational post content here...", fontSize = 12.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp)
                                .testTag("edu_post_content_input"),
                            shape = RoundedCornerShape(8.dp),
                            maxLines = 5,
                            textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
                        )

                        Button(
                            onClick = {
                                if (newTitle.isNotBlank() && newCategory.isNotBlank() && newContent.isNotBlank()) {
                                    onCreatePost(newTitle, newCategory, newContent)
                                    newTitle = ""
                                    newCategory = ""
                                    newContent = ""
                                    showCreateForm = false
                                    android.widget.Toast.makeText(context, "Successfully posted to Student Feed!", android.widget.Toast.LENGTH_SHORT).show()
                                } else {
                                    android.widget.Toast.makeText(context, "Please fill out all fields before posting.", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("edu_submit_post_btn"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Post", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Post to Feed", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Student Feed Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Student Feed (${filteredPosts.size} posts)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (!showCreateForm) {
                    TextButton(
                        onClick = { showCreateForm = true },
                        modifier = Modifier.testTag("edu_create_post_text_btn")
                    ) {
                        Icon(Icons.Default.Create, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("New Post", fontSize = 12.sp)
                    }
                }
            }
        }

        // Student Posts List
        if (filteredPosts.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = "No Results",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No matching posts found.",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Try searching another term or tap 'New Post' above to add content.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(filteredPosts, key = { it.id }) { post ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edu_post_card_${post.id}"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Title & Category tag
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = post.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = post.category,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Author and Timestamp
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Author",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = post.author,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text("•", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = post.timestamp,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Content Body
                        Text(
                            text = post.content,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                        Spacer(modifier = Modifier.height(8.dp))

                        // Action Buttons (Like, Share, Delete)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Like
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onToggleLike(post.id) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                    .testTag("edu_like_btn_${post.id}")
                            ) {
                                Icon(
                                    imageVector = if (post.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                    contentDescription = "Like",
                                    tint = if (post.isLiked) Color(0xFFE91E63) else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${post.likesCount}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (post.isLiked) Color(0xFFE91E63) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                // Share
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                        val clip = android.content.ClipData.newPlainText("EduConnect Post", "${post.title}\nCategory: ${post.category}\n\n${post.content}")
                                        clipboard.setPrimaryClip(clip)
                                        android.widget.Toast.makeText(context, "Copied post content to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .testTag("edu_share_btn_${post.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Share",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                // Delete
                                IconButton(
                                    onClick = {
                                        onDeletePost(post.id)
                                        android.widget.Toast.makeText(context, "Post removed.", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .size(32.dp)
                                        .testTag("edu_delete_btn_${post.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

