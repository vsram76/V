package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.api.RetrofitClient
import com.example.model.Content
import com.example.model.GenerateContentRequest
import com.example.model.Part
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AppInfo(
    val name: String,
    val packageName: String,
    val targetSdkVersion: Int,
    val versionName: String,
    val isSystemApp: Boolean
)

enum class SenderType {
    USER, GEMINI_SUPPORT
}

data class ChatMessage(
    val id: String,
    val sender: SenderType,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class FeatureLabState(
    val isPrivateSpaceUnlocked: Boolean = false,
    val privateSpacePin: String = "",
    val activeStatusChip: String? = null,
    val archivedApps: Map<String, Boolean> = mapOf(
        "com.google.android.youtube" to false,
        "com.google.android.apps.photos" to false,
        "com.android.chrome" to false,
        "com.example.mockgame" to false
    ),
    val notificationCooldownSpamCount: Int = 0,
    val isNotificationCooledDown: Boolean = false
)

data class DiagnosticLog(
    val id: String,
    val timestamp: String,
    val component: String,
    val level: String, // INFO, WARN, ERROR, DEBUG
    val message: String
)

data class DiagnosticsState(
    val sdkVersion: Int = Build.VERSION.SDK_INT,
    val androidVersion: String = if (Build.VERSION.SDK_INT >= 36) "16 (Baklava)" else "15 (Vanilla Ice Cream) [Simulating 16 API]",
    val deviceModel: String = "${Build.MANUFACTURER} ${Build.MODEL}",
    val googlePlayServicesStatus: String = "Up to Date (V26.24.12)",
    val cpuArchitecture: String = Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown",
    val mockAvailableStorageGB: Int = 184,
    val mockTotalStorageGB: Int = 256,
    val mockRamUsagePercent: Int = 42,
    val systemLogs: List<DiagnosticLog> = emptyList(),
    val logsSearchQuery: String = "",
    val selectedLogLevelFilter: String = "ALL",
    val isRefreshingLogs: Boolean = false
)

import com.example.service.SiriIntegrationServer

data class SiriState(
    val isListening: Boolean = false,
    val voiceTranscript: String = "",
    val siriResponse: String = "Hi! I am Siri, your intelligent virtual companion adapted for Android 16. Tap the glowing wave or my mic below, and ask me anything!",
    val isGenerating: Boolean = false,
    val responseHistory: List<Pair<String, String>> = emptyList(),
    val isServerRunning: Boolean = false,
    val serverUrl: String = "",
    val serverLogs: List<String> = emptyList()
)

data class EduPost(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val category: String,
    val content: String,
    val timestamp: String = "Just now",
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val author: String = "Student Developer"
)

data class EduConnectState(
    val posts: List<EduPost> = listOf(
        EduPost(
            id = "1",
            title = "Getting Started with Python",
            category = "Programming",
            content = "Python is a high-level programming language known for its readability. It's heavily used in data science, automation, machine learning, and web backend development.",
            timestamp = "2 hours ago",
            likesCount = 14,
            isLiked = false,
            author = "Alex Chen"
        ),
        EduPost(
            id = "2",
            title = "HTML & CSS Basics",
            category = "Web Development",
            content = "Learn how to build responsive web layouts using CSS Flexbox and Grid. HTML provides structural markup while CSS handles modern visual styling.",
            timestamp = "5 hours ago",
            likesCount = 22,
            isLiked = true,
            author = "Maria Garcia"
        ),
        EduPost(
            id = "3",
            title = "Database Management Systems",
            category = "Database",
            content = "SQL is used to query relational databases like MySQL and PostgreSQL. Learn ACID compliance and normalization rules for scalable data storage.",
            timestamp = "1 day ago",
            likesCount = 31,
            isLiked = false,
            author = "Dev Team"
        ),
        EduPost(
            id = "4",
            title = "Understanding Binary Code",
            category = "Digital Electronics",
            content = "Computers use binary (base-2) numbering systems consisting of 0s and 1s to process information. Each 0 or 1 is called a bit, and 8 bits form a byte.",
            timestamp = "2 days ago",
            likesCount = 19,
            isLiked = false,
            author = "Prof. Kumar"
        )
    ),
    val searchQuery: String = "",
    val selectedCategoryFilter: String = "ALL"
)

data class SystemHubUiState(
    val installedApps: List<AppInfo> = emptyList(),
    val searchQuery: String = "",
    val isLoadingApps: Boolean = false,
    val chatHistory: List<ChatMessage> = emptyList(),
    val isChatLoading: Boolean = false,
    val chatError: String? = null,
    val featureLab: FeatureLabState = FeatureLabState(),
    val diagnostics: DiagnosticsState = DiagnosticsState(),
    val siriState: SiriState = SiriState(),
    val eduConnect: EduConnectState = EduConnectState()
)

class SystemCompanionViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(SystemHubUiState())
    val uiState: StateFlow<SystemHubUiState> = _uiState.asStateFlow()

    init {
        // Load real system apps
        loadInstalledApps()
        // Welcome message from Google Support
        sendWelcomeMessage()
        // Initialize default diagnostic logs
        initializeDefaultLogs()
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingApps = true) }
            val appList = withContext(Dispatchers.IO) {
                val context = getApplication<Application>().applicationContext
                val pm = context.packageManager
                try {
                    val packages = pm.getInstalledPackages(0)
                    packages.map { pack ->
                        val appInfo = pack.applicationInfo
                        val name = pm.getApplicationLabel(appInfo).toString()
                        val packageName = pack.packageName
                        val targetSdkVersion = appInfo.targetSdkVersion
                        val versionName = pack.versionName ?: "1.0"
                        val isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                        AppInfo(name, packageName, targetSdkVersion, versionName, isSystemApp)
                    }.sortedBy { it.name }
                } catch (e: Exception) {
                    Log.e("ViewModel", "Error loading apps", e)
                    emptyList()
                }
            }
            _uiState.update { it.copy(installedApps = appList, isLoadingApps = false) }
        }
    }

    private fun sendWelcomeMessage() {
        val welcomeText = "Hello! I am your Google Support Assistant for Android 16. " +
                "I can help you analyze the apps installed on this system, troubleshoot issues, or explain upcoming features in Android 16 (Baklava). How can I assist you today?"
        val welcomeMsg = ChatMessage(
            id = "welcome",
            sender = SenderType.GEMINI_SUPPORT,
            text = welcomeText
        )
        _uiState.update { it.copy(chatHistory = listOf(welcomeMsg)) }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return

        val userMsg = ChatMessage(
            id = System.nanoTime().toString(),
            sender = SenderType.USER,
            text = text
        )

        _uiState.update { 
            it.copy(
                chatHistory = it.chatHistory + userMsg,
                isChatLoading = true,
                chatError = null
            )
        }

        viewModelScope.launch {
            try {
                val responseText = queryGemini(text)
                val assistantMsg = ChatMessage(
                    id = System.nanoTime().toString(),
                    sender = SenderType.GEMINI_SUPPORT,
                    text = responseText
                )
                _uiState.update { 
                    it.copy(
                        chatHistory = it.chatHistory + assistantMsg,
                        isChatLoading = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update { 
                    it.copy(
                        isChatLoading = false,
                        chatError = "Failed to reach Google Support. Details: ${e.localizedMessage}. Please check your internet connection."
                    )
                }
            }
        }
    }

    private suspend fun queryGemini(userPrompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Google Support is running in Offline Mode because the Gemini API Key is not set. Please add your GEMINI_API_KEY in the Secrets panel of Google AI Studio to enable interactive support answers!"
        }

        // Include system instructions for the expert Google Support representative
        val systemInstructionText = "You are a professional, helpful, and highly knowledgeable Google Support Specialist " +
                "assisting users with Android 16 (codename Baklava, API Level 36). Your answers must be friendly, " +
                "technical yet clear, and formatted nicely in bullet points where appropriate. " +
                "The user is viewing a system companion app. Support the user's queries about Android 16 features " +
                "(such as Notification Cool-down, Private Spaces, App Archiving, or custom API 36 policies) and help troubleshoot apps."

        // Build conversation context
        val currentChatHistory = _uiState.value.chatHistory
        // Take the last 6 messages to keep context without hitting token limits
        val contextContents = mutableListOf<Content>()
        
        currentChatHistory.takeLast(6).forEach { msg ->
            val rolePart = if (msg.sender == SenderType.USER) "user" else "model"
            // Wait, standard Gemini API has a specific content role structure:
            // "contents": [{"parts": [{"text": "prompt"}], "role": "user"}]
            // Let's keep it simple: we can construct a prompt containing the conversation history for single-shot,
            // or build a clean message representation.
            // Let's build a consolidated rich prompt with history to avoid complex multi-role serialization issues.
        }

        // Consolidated prompt construction
        val chatContextBuilder = StringBuilder()
        chatContextBuilder.append("System Context: You are a Google Support Specialist assisting with Android 16.\n")
        
        _uiState.value.chatHistory.takeLast(6).forEach { msg ->
            val senderLabel = if (msg.sender == SenderType.USER) "User" else "Google Support"
            chatContextBuilder.append("$senderLabel: ${msg.text}\n")
        }
        chatContextBuilder.append("User (Latest Question): $userPrompt\n")
        chatContextBuilder.append("Google Support:")

        val finalPrompt = chatContextBuilder.toString()

        val request = GenerateContentRequest(
            contents = listOf(
                Content(parts = listOf(Part(text = finalPrompt)))
            ),
            systemInstruction = Content(parts = listOf(Part(text = systemInstructionText)))
        )

        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "I apologize, I could not generate a response at this moment. Please try again."
        } catch (e: Exception) {
            Log.e("ViewModel", "Gemini API failure", e)
            "I encountered an error connecting to Google Support servers: ${e.message}. " +
                    "Please verify your GEMINI_API_KEY in AI Studio or check your connection."
        }
    }

    // --- Feature Lab Simulation Actions ---

    fun togglePrivateSpaceLock(pinCode: String = "") {
        _uiState.update { state ->
            val lab = state.featureLab
            if (lab.isPrivateSpaceUnlocked) {
                // Lock it
                logDiagnosticEvent("PrivateSpaceManager", "INFO", "Private Space locked. Secure sandbox active.")
                state.copy(featureLab = lab.copy(isPrivateSpaceUnlocked = false, privateSpacePin = ""))
            } else {
                // If locking or unlocking with code
                if (pinCode == "1234" || pinCode.isEmpty()) {
                    logDiagnosticEvent("PrivateSpaceManager", "INFO", "Private Space unlocked successfully.")
                    state.copy(featureLab = lab.copy(isPrivateSpaceUnlocked = true, privateSpacePin = pinCode))
                } else {
                    logDiagnosticEvent("PrivateSpaceManager", "WARN", "Private Space unlock attempt failed. Incorrect PIN code entered.")
                    state // Wrong pin
                }
            }
        }
    }

    fun triggerStatusChip(chipName: String?) {
        _uiState.update { state ->
            state.copy(featureLab = state.featureLab.copy(activeStatusChip = chipName))
        }
    }

    fun toggleAppArchive(packageName: String) {
        _uiState.update { state ->
            val lab = state.featureLab
            val currentArchived = lab.archivedApps[packageName] ?: false
            val newArchivedApps = lab.archivedApps.toMutableMap().apply {
                put(packageName, !currentArchived)
            }
            logDiagnosticEvent("AppArchiver", "INFO", "App archive state toggled for $packageName. Archived: ${!currentArchived}")
            state.copy(featureLab = lab.copy(archivedApps = newArchivedApps))
        }
    }

    fun triggerNotificationSpam() {
        _uiState.update { state ->
            val lab = state.featureLab
            val newCount = lab.notificationCooldownSpamCount + 1
            val cooledDown = newCount >= 4
            logDiagnosticEvent(
                "NotificationService",
                if (cooledDown) "ERROR" else "WARN",
                "Spam alert triggered ($newCount). ${if (cooledDown) "COOLDOWN ACTIVATED - alerts throttled" else "Alert frequency high."}"
            )
            state.copy(
                featureLab = lab.copy(
                    notificationCooldownSpamCount = newCount,
                    isNotificationCooledDown = cooledDown
                )
            )
        }
    }

    fun resetNotificationCooldown() {
        _uiState.update { state ->
            logDiagnosticEvent("NotificationService", "INFO", "Reset notification cooldown tracker. Counters initialized to 0.")
            state.copy(
                featureLab = state.featureLab.copy(
                    notificationCooldownSpamCount = 0,
                    isNotificationCooledDown = false
                )
            )
        }
    }

    fun askSupportAboutApp(app: AppInfo) {
        val query = "Can you help me analyze '${app.name}' (${app.packageName})? It targets SDK level ${app.targetSdkVersion}. What should I keep in mind regarding background optimization and privacy permissions for this app under Android 16?"
        sendMessage(query)
    }

    // --- Siri Voice Assistant Simulation Actions ---

    fun triggerSiriSpeech(userSpeech: String) {
        if (userSpeech.isBlank()) return

        _uiState.update { state ->
            state.copy(
                siriState = state.siriState.copy(
                    isGenerating = true,
                    voiceTranscript = userSpeech
                )
            )
        }

        viewModelScope.launch {
            val responseText = queryGeminiSiri(userSpeech)
            _uiState.update { state ->
                val updatedHistory = state.siriState.responseHistory + Pair(userSpeech, responseText)
                state.copy(
                    siriState = state.siriState.copy(
                        isGenerating = false,
                        siriResponse = responseText,
                        responseHistory = updatedHistory
                    )
                )
            }
        }
    }

    fun toggleSiriListening() {
        val currentlyListening = _uiState.value.siriState.isListening
        if (currentlyListening) {
            // Stop listening
            _uiState.update { state ->
                state.copy(siriState = state.siriState.copy(isListening = false))
            }
        } else {
            // Start listening
            _uiState.update { state ->
                state.copy(siriState = state.siriState.copy(isListening = true, voiceTranscript = "Listening..."))
            }
            
            // Auto-trigger a simulated speech request after some listening time if no custom input is provided
            viewModelScope.launch {
                kotlinx.coroutines.delay(2200)
                if (_uiState.value.siriState.isListening) {
                    _uiState.update { state ->
                        state.copy(siriState = state.siriState.copy(isListening = false))
                    }
                    val sampleQueries = listOf(
                        "Hey Siri, what features does Android 16 have?",
                        "Hey Siri, check my system diagnostics and RAM health.",
                        "Hey Siri, why is the Baklava dessert chosen for Android 16?",
                        "Hey Siri, inspect my installed system apps."
                    )
                    triggerSiriSpeech(sampleQueries.random())
                }
            }
        }
    }

    fun clearSiriHistory() {
        _uiState.update { state ->
            state.copy(
                siriState = state.siriState.copy(
                    responseHistory = emptyList(),
                    siriResponse = "History cleared. Speak or type to start a new chat!"
                )
            )
        }
    }

    private suspend fun queryGeminiSiri(userPrompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext "Hi! I am Siri, running as a virtual voice assistant companion. To enable my real-time speech responses, make sure to add your GEMINI_API_KEY in the Secrets panel."
        }

        val systemInstructionText = "You are Siri, an intelligent, helpful, witty, and high-fidelity virtual assistant running on the new Android 16 (Baklava) OS system companion app. " +
                "Your responses must be relatively short (under 3 sentences), highly engaging, crisp, and conversational, matching a voice assistant's speech. " +
                "If the user asks about the device status, Android 16 features, or apps, give them custom, witty answers tailored to those topics. " +
                "Reference the fact that you are running on Android 16 and can assist them with app inspections, notification cool-down labs, and diagnostics!"

        val conversationBuilder = StringBuilder()
        conversationBuilder.append("System Context: You are Siri, voice companion on Android 16.\n")
        _uiState.value.siriState.responseHistory.takeLast(4).forEach { (user, siri) ->
            conversationBuilder.append("User: $user\n")
            conversationBuilder.append("Siri: $siri\n")
        }
        conversationBuilder.append("User: $userPrompt\n")
        conversationBuilder.append("Siri:")

        val finalPrompt = conversationBuilder.toString()

        val request = GenerateContentRequest(
            contents = listOf(
                Content(parts = listOf(Part(text = finalPrompt)))
            ),
            systemInstruction = Content(parts = listOf(Part(text = systemInstructionText)))
        )

        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "I didn't quite catch that. Could you please repeat?"
        } catch (e: Exception) {
            Log.e("ViewModel", "Siri Gemini failure", e)
            "I'm having trouble connecting to the network right now. Please check your connection and try again."
        }
    }

    // --- Siri Webhook / Integration Server Controller ---

    private var siriServer: SiriIntegrationServer? = null

    fun toggleSiriServer() {
        val currentRunning = _uiState.value.siriState.isServerRunning
        if (currentRunning) {
            siriServer?.stop()
            siriServer = null
            logDiagnosticEvent("SiriServer", "INFO", "Siri Shortcuts API integration server stopped.")
            _uiState.update { state ->
                state.copy(
                    siriState = state.siriState.copy(
                        isServerRunning = false,
                        serverUrl = ""
                    )
                )
            }
        } else {
            logDiagnosticEvent("SiriServer", "INFO", "Siri Shortcuts API integration server starting up on port 8888.")
            val context = getApplication<Application>().applicationContext
            siriServer = SiriIntegrationServer(
                context = context,
                port = 8888,
                onCommandReceived = { cmd -> handleSiriServerCommand(cmd) },
                getDiagnostics = { _uiState.value.diagnostics },
                getApps = { _uiState.value.installedApps },
                onRequestLogged = { logSiriServerRequest(it) }
            )
            val ip = siriServer?.start() ?: ""
            if (ip.isNotEmpty()) {
                _uiState.update { state ->
                    state.copy(
                        siriState = state.siriState.copy(
                            isServerRunning = true,
                            serverUrl = "http://$ip:8888"
                        )
                    )
                }
            }
        }
    }

    private fun logSiriServerRequest(logLine: String) {
        val timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        logDiagnosticEvent("SiriServer", "DEBUG", "Shortcuts client request: $logLine")
        _uiState.update { state ->
            val updatedLogs = (state.siriState.serverLogs + "[$timestamp] $logLine").takeLast(30)
            state.copy(
                siriState = state.siriState.copy(
                    serverLogs = updatedLogs
                )
            )
        }
    }

    private fun handleSiriServerCommand(command: String): String {
        val normalized = command.lowercase().trim()
        return when {
            normalized.contains("diagnostic") || normalized.contains("status") -> {
                val diag = _uiState.value.diagnostics
                "Android 16 diagnostics check complete. Device is ${diag.deviceModel} running Android ${diag.androidVersion}. RAM utilization is at ${diag.mockRamUsagePercent} percent, and ${diag.mockAvailableStorageGB} GigaBytes of storage are available."
            }
            normalized.contains("apps") || normalized.contains("installed") -> {
                val appCount = _uiState.value.installedApps.size
                val sample = _uiState.value.installedApps.take(3).joinToString { it.name }
                "You have $appCount apps installed on this Android 16 device. Highlights include $sample."
            }
            normalized.contains("spam") || normalized.contains("notification") -> {
                triggerNotificationSpam()
                "Notification cooling down stress-test triggered. Warning: multiple spam alerts are firing on Android 16!"
            }
            normalized.contains("cooldown") || normalized.contains("reset") -> {
                resetNotificationCooldown()
                "Notification cooldown timer reset successfully."
            }
            normalized.contains("unlock") || normalized.contains("private") -> {
                togglePrivateSpaceLock(true)
                "Private Space partition unlocked successfully on Android 16."
            }
            else -> {
                // Synthesize dynamically using Gemini AI voice mode
                val synthesizedResponse = kotlinx.coroutines.runBlocking {
                    queryGeminiSiri(command)
                }
                synthesizedResponse
            }
        }
    }

    private fun initializeDefaultLogs() {
        val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
        val baseTime = System.currentTimeMillis()
        
        val initialLogs = listOf(
            DiagnosticLog("init_1", sdf.format(baseTime - 300000), "SystemServer", "INFO", "Android 16 virtual secure sandbox container fully initialized."),
            DiagnosticLog("init_2", sdf.format(baseTime - 280000), "SecurityShield", "INFO", "Google Play Protect completed device integrity scan. 0 threats found."),
            DiagnosticLog("init_3", sdf.format(baseTime - 250000), "PrivateSpaceManager", "INFO", "Private Space secure partition initialized. Status: Locked."),
            DiagnosticLog("init_4", sdf.format(baseTime - 220000), "NotificationService", "INFO", "Notification cooldown controller registered for API Level 36 compatibility."),
            DiagnosticLog("init_5", sdf.format(baseTime - 190000), "PackageManager", "INFO", "Scanned installed package directories. Multi-category cache warmed."),
            DiagnosticLog("init_6", sdf.format(baseTime - 160000), "SiriServer", "INFO", "Siri shortcuts webhook router listener compiled."),
            DiagnosticLog("init_7", sdf.format(baseTime - 130000), "CpuMonitor", "DEBUG", "Thermal throttle limits verified. Current sensor values within margins."),
            DiagnosticLog("init_8", sdf.format(baseTime - 100000), "RamManager", "INFO", "RAM allocation sandbox established at 3.4 GB partition limit."),
            DiagnosticLog("init_9", sdf.format(baseTime - 50000), "AppArchiver", "DEBUG", "App archiving daemon started. Monitoring inactive application resources.")
        )
        
        _uiState.update { state ->
            state.copy(diagnostics = state.diagnostics.copy(systemLogs = initialLogs))
        }
    }

    fun logDiagnosticEvent(component: String, level: String, message: String) {
        val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
        val timestamp = sdf.format(java.util.Date())
        val newLog = DiagnosticLog(
            id = System.nanoTime().toString(),
            timestamp = timestamp,
            component = component,
            level = level,
            message = message
        )
        _uiState.update { state ->
            val updatedLogs = (state.diagnostics.systemLogs + newLog).takeLast(100)
            state.copy(diagnostics = state.diagnostics.copy(systemLogs = updatedLogs))
        }
    }

    fun updateLogsSearchQuery(query: String) {
        _uiState.update { state ->
            state.copy(diagnostics = state.diagnostics.copy(logsSearchQuery = query))
        }
    }

    fun updateLogLevelFilter(level: String) {
        _uiState.update { state ->
            state.copy(diagnostics = state.diagnostics.copy(selectedLogLevelFilter = level))
        }
    }

    fun refreshDiagnosticLogs() {
        viewModelScope.launch {
            _uiState.update { state ->
                state.copy(diagnostics = state.diagnostics.copy(isRefreshingLogs = true))
            }
            kotlinx.coroutines.delay(800)
            
            // Generate a fresh random diagnostic entry when pulling system log data
            val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            val timestamp = sdf.format(java.util.Date())
            
            val randomLogs = listOf(
                DiagnosticLog(System.nanoTime().toString(), timestamp, "CpuMonitor", "INFO", "CPU thermal status updated: Temp is ${35 + (2..12).random()}C. System runs optimal."),
                DiagnosticLog(System.nanoTime().toString(), timestamp, "RamManager", "DEBUG", "Garbage collection completed. Reclaimed virtual buffer space."),
                DiagnosticLog(System.nanoTime().toString(), timestamp, "SecurityShield", "INFO", "Periodic Play Protect background sandbox checksum verified."),
                DiagnosticLog(System.nanoTime().toString(), timestamp, "SystemServer", "INFO", "WIFI interfaces scanned. Inter-process socket latency under 4ms."),
                DiagnosticLog(System.nanoTime().toString(), timestamp, "NotificationService", "DEBUG", "Scanned notification queue. Active cooling-down throttling is verified.")
            )
            
            _uiState.update { state ->
                val updatedLogs = (state.diagnostics.systemLogs + randomLogs.random()).takeLast(100)
                state.copy(
                    diagnostics = state.diagnostics.copy(
                        systemLogs = updatedLogs,
                        isRefreshingLogs = false
                    )
                )
            }
        }
    }

    fun updateEduSearchQuery(query: String) {
        _uiState.update { state ->
            state.copy(eduConnect = state.eduConnect.copy(searchQuery = query))
        }
    }

    fun updateEduCategoryFilter(category: String) {
        _uiState.update { state ->
            state.copy(eduConnect = state.eduConnect.copy(selectedCategoryFilter = category))
        }
    }

    fun createEduPost(title: String, category: String, content: String) {
        if (title.isBlank() || category.isBlank() || content.isBlank()) return
        val newPost = EduPost(
            title = title.trim(),
            category = category.trim(),
            content = content.trim(),
            timestamp = "Just now",
            likesCount = 0,
            isLiked = false,
            author = "Student Developer"
        )
        _uiState.update { state ->
            state.copy(
                eduConnect = state.eduConnect.copy(
                    posts = listOf(newPost) + state.eduConnect.posts
                )
            )
        }
    }

    fun toggleEduPostLike(postId: String) {
        _uiState.update { state ->
            val updatedPosts = state.eduConnect.posts.map { post ->
                if (post.id == postId) {
                    val newIsLiked = !post.isLiked
                    val newLikesCount = if (newIsLiked) post.likesCount + 1 else (post.likesCount - 1).coerceAtLeast(0)
                    post.copy(isLiked = newIsLiked, likesCount = newLikesCount)
                } else post
            }
            state.copy(eduConnect = state.eduConnect.copy(posts = updatedPosts))
        }
    }

    fun deleteEduPost(postId: String) {
        _uiState.update { state ->
            val updatedPosts = state.eduConnect.posts.filterNot { it.id == postId }
            state.copy(eduConnect = state.eduConnect.copy(posts = updatedPosts))
        }
    }

    override fun onCleared() {
        super.onCleared()
        siriServer?.stop()
    }
}
