package com.example.service

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import com.example.viewmodel.AppInfo
import com.example.viewmodel.DiagnosticsState
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpHandler
import com.sun.net.httpserver.HttpServer
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.nio.charset.StandardCharsets
import java.util.Collections
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

class SiriIntegrationServer(
    private val context: Context,
    private val port: Int = 8888,
    private val onCommandReceived: (String) -> String,
    private val getDiagnostics: () -> DiagnosticsState,
    private val getApps: () -> List<AppInfo>,
    private val onRequestLogged: (String) -> Unit
) {
    private var server: HttpServer? = null
    private val executor = Executors.newSingleThreadExecutor()

    fun start(): String {
        return try {
            if (server != null) {
                return getLocalIpAddress() ?: "127.0.0.1"
            }
            val ip = getLocalIpAddress() ?: "0.0.0.0"
            server = HttpServer.create(InetSocketAddress(port), 0).apply {
                createContext("/siri/diagnostics", DiagnosticsHandler())
                createContext("/siri/apps", AppsHandler())
                createContext("/siri/command", CommandHandler())
                executor = this@SiriIntegrationServer.executor
                start()
            }
            Log.d("SiriServer", "Siri API Server started on http://$ip:$port")
            onRequestLogged("Server initialized successfully on http://$ip:$port")
            ip
        } catch (e: Exception) {
            Log.e("SiriServer", "Failed to start Siri server", e)
            onRequestLogged("Error starting server: ${e.localizedMessage}")
            ""
        }
    }

    fun stop() {
        try {
            server?.stop(0)
            server = null
            onRequestLogged("Server stopped successfully.")
        } catch (e: Exception) {
            Log.e("SiriServer", "Error stopping server", e)
        }
    }

    private fun getLocalIpAddress(): String? {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                val addrs = Collections.list(intf.inetAddresses)
                for (addr in addrs) {
                    if (!addr.isLoopbackAddress) {
                        val sAddr = addr.hostAddress
                        val isIPv4 = sAddr.indexOf(':') < 0
                        if (isIPv4) {
                            return sAddr
                        }
                    }
                }
            }
        } catch (ex: Exception) {
            Log.e("SiriServer", "Error getting IP", ex)
        }
        return "127.0.0.1"
    }

    private fun sendResponse(exchange: HttpExchange, statusCode: Int, jsonResponse: String) {
        val bytes = jsonResponse.toByteArray(StandardCharsets.UTF_8)
        exchange.responseHeaders.set("Content-Type", "application/json; charset=utf-8")
        exchange.responseHeaders.set("Access-Control-Allow-Origin", "*")
        exchange.sendResponseHeaders(statusCode, bytes.size.toLong())
        val os: OutputStream = exchange.responseBody
        os.write(bytes)
        os.close()
    }

    private inner class DiagnosticsHandler : HttpHandler {
        override fun handle(exchange: HttpExchange) {
            try {
                onRequestLogged("GET /siri/diagnostics from ${exchange.remoteAddress}")
                val diag = getDiagnostics()
                val json = JSONObject().apply {
                    put("status", "success")
                    put("sdk_version", diag.sdkVersion)
                    put("android_version", diag.androidVersion)
                    put("device_model", diag.deviceModel)
                    put("google_play_services", diag.googlePlayServicesStatus)
                    put("cpu_architecture", diag.cpuArchitecture)
                    put("storage_available_gb", diag.mockAvailableStorageGB)
                    put("storage_total_gb", diag.mockTotalStorageGB)
                    put("ram_usage_percent", diag.mockRamUsagePercent)
                }
                sendResponse(exchange, 200, json.toString())
            } catch (e: Exception) {
                sendResponse(exchange, 500, "{\"error\":\"${e.localizedMessage}\"}")
            }
        }
    }

    private inner class AppsHandler : HttpHandler {
        override fun handle(exchange: HttpExchange) {
            try {
                onRequestLogged("GET /siri/apps from ${exchange.remoteAddress}")
                val appsList = getApps()
                val jsonArray = JSONArray()
                appsList.take(20).forEach { app ->
                    val appJson = JSONObject().apply {
                        put("name", app.name)
                        put("packageName", app.packageName)
                        put("targetSdkVersion", app.targetSdkVersion)
                        put("versionName", app.versionName)
                        put("isSystemApp", app.isSystemApp)
                    }
                    jsonArray.put(appJson)
                }
                val json = JSONObject().apply {
                    put("status", "success")
                    put("total_apps_count", appsList.size)
                    put("inspected_apps", jsonArray)
                }
                sendResponse(exchange, 200, json.toString())
            } catch (e: Exception) {
                sendResponse(exchange, 500, "{\"error\":\"${e.localizedMessage}\"}")
            }
        }
    }

    private inner class CommandHandler : HttpHandler {
        override fun handle(exchange: HttpExchange) {
            try {
                val query = exchange.requestURI.query ?: ""
                val command = if (query.startsWith("cmd=")) {
                    java.net.URLDecoder.decode(query.substring(4), "UTF-8")
                } else {
                    "status"
                }

                onRequestLogged("POST /siri/command?cmd=$command from ${exchange.remoteAddress}")
                val commandResult = onCommandReceived(command)

                val json = JSONObject().apply {
                    put("status", "success")
                    put("executed_command", command)
                    put("siri_speech_output", commandResult)
                }
                sendResponse(exchange, 200, json.toString())
            } catch (e: Exception) {
                sendResponse(exchange, 500, "{\"error\":\"${e.localizedMessage}\"}")
            }
        }
    }
}
